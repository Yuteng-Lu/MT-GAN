from PIL import Image, ImageTk
import tkinter as tk


def resize(w, h, w_box, h_box, image):
    f1 = w_box / w
    f2 = h_box / h
    factor = max([f1, f2])
    width = int(w * factor)
    height = int(h * factor)
    return image.resize((width, height), Image.Resampling.LANCZOS)


def all_zero(my_list):
    for val in my_list:
        if isinstance(val, list):
            if not all_zero(val):
                return False
        else:
            # print(val)
            if val != 0:
                return False
    return True


def create_window():
    window = tk.Tk()
    window2 = tk.Toplevel()
    window2.destroy()
    window3 = tk.Toplevel()
    window3.destroy()
    window4 = tk.Toplevel()
    window4.destroy()
    route = f'wallpaper\\cyan.jpg'
    image = Image.open(route)
    w, h = 1280, 800
    w_, h_ = image.size
    y = 0
    image_resized = resize(w_, h_, w, h, image)
    tk_image = ImageTk.PhotoImage(image_resized)
    background_label = tk.Label(window, image=tk_image)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)

    for i in range(2):
        window.rowconfigure(i, weight=1, minsize=300)
    for j in range(2):
        window.columnconfigure(j, weight=1, minsize=240)

    frame = []
    title = [['-----------Dataset-----------', '-----Mutation Operators-----'],
             ['--------More Options--------', '----------Start here----------']]
    for i in range(len(title)):
        frame.append([])
        for j in range(len(title[i])):
            frame[-1].append(tk.Frame(master=window, borderwidth=1))
            frame[i][j].grid(row=i, column=j, padx=5, pady=5)
            label = tk.Label(master=frame[i][j], text=title[i][j])
            label.pack(padx=5, pady=5)

    # frame (0, 0)
    my_frame = frame[0][0]
    text1 = ['MNIST']

    def sel():
        selection = f'You selected {text1[RadioVar.get()]}'
        label1.config(text=selection)
        selection = f'see details at {text1[RadioVar.get()]}.py'
        label2.config(text=selection)

    RadioVar = tk.IntVar()
    R1 = []

    for k in range(len(text1)):
        RadioButton = tk.Radiobutton(my_frame, text=text1[k], variable=RadioVar, value=k, command=sel)
        R1.append(RadioButton)
        if k % 2 == 0:
            RadioButton.pack(anchor='w')
            RadioButton.update()
            y = RadioButton.winfo_y() - 1
        else:
            RadioButton.place(x=90, y=y)

    label1 = tk.Label(my_frame)
    label1.pack()

    label = tk.Label(master=my_frame, text='-----------Model-------------')
    label.pack()

    label = tk.Label(my_frame, text='model name')
    entry1 = tk.Entry(my_frame, width=10)
    label.pack(anchor='w', padx=5, pady=5)
    label.update()
    y = label.winfo_y() - 1
    entry1.place(x=90, y=y)

    label2 = tk.Label(my_frame)
    label2.pack()
    sel()

    # frame (0, 1)
    my_frame = frame[0][1]
    valid_modes = ['after_train', 'change_batch', 'change_dataset', 'change_model', 'change_optimizer', 'train_error']
    detail_modes = {
        0: ['after_train_GF', 'after_train_NS', 'after_train_WS'],
        1: ['batch_decrease', 'batch_increase'],
        2: ['change_normalization', 'noise_exponential', 'noise_gamma', 'noise_gauss'],
        3: ['change_discriminator', 'change_generator'],
        4: ['change_both_optimizer', 'change_discriminator_optimizer', 'change_generator_optimizer'],
        5: ['confuse_discriminator', 'random_reduction']
    }

    def det():
        nonlocal window2
        window2.destroy()
        window2 = tk.Toplevel()
        RadioVar3.set(0)
        index = RadioVar2.get()

        label_ = tk.Label(master=window2, text='-----------Detail Mode-----------')
        label_.pack()

        for j_index in range(len(detail_modes[index])):
            R = tk.Radiobutton(window2, text=detail_modes[index][j_index], variable=RadioVar3, value=j_index)
            R.pack(anchor='w')

        window2.mainloop()

    RadioVar2 = tk.IntVar()
    RadioVar3 = tk.IntVar()

    for k in range(len(valid_modes)):
        RadioButton = tk.Radiobutton(my_frame, text=valid_modes[k], variable=RadioVar2, value=k, command=det)
        RadioButton.pack(anchor='w')

    RadioButton = tk.Radiobutton(my_frame, variable=RadioVar2, value=-1)
    RadioButton.select()

    def set3():
        nonlocal window3
        window3.destroy()
        window3 = tk.Toplevel()
        label_ = tk.Label(master=window3, text='set mutation ratio and details at tools.py')
        label_.pack()
        window3.mainloop()

    Button = tk.Button(my_frame, text='set details', command=set3, width=20, bg='cyan')
    Button.pack(padx=5, pady=5)

    # frame (1, 0)
    my_frame = frame[1][0]

    text5 = ['dataset', 'model', 'operators']
    RadioVar5 = tk.IntVar()
    R5 = []

    for k in range(len(text5)):
        RadioButton = tk.Radiobutton(my_frame, text=text5[k], variable=RadioVar5, value=k, command=sel)
        R5.append(RadioButton)
        if k % 2 == 0:
            RadioButton.pack(anchor='w')
            RadioButton.update()
            y = RadioButton.winfo_y() - 1
        else:
            R5[-1].update()
            RadioButton.place(x=90, y=y)

    RadioButton = tk.Radiobutton(my_frame, variable=RadioVar5, value=-1)
    RadioButton.select()

    def show():
        if RadioVar5.get() < 0:
            return

        nonlocal window4
        window4.destroy()
        window4 = tk.Toplevel()

        if RadioVar5.get() == 0:
            tk.Label(master=window4, text='To create a new dataset X, create X.py and put\n'
                                          'l_dim, define_discriminator, define_generator, \n'
                                          'define_gan, and load_real_samples into it.       \n'
                                          'Import your dataset in create_window.play.     ').pack()

        elif RadioVar5.get() == 1:
            tk.Label(master=window4, text='Functions define_discriminator, define_generator,\n'
                                          'and define_gan make up the whole model. You  \n'
                                          'can use the \'name\' argument to create different \n'
                                          'original models.                                    '
                                          '           ').pack()

        else:  # RadioVar5.get() == 2:
            tk.Label(master=window4, text='Operators are implemented in main.test.\n'
                                          'Parameters are all shown in tools.py.      ').pack(anchor='w')

        window4.mainloop()

    Button = tk.Button(my_frame, text='submit', width=10, height=1, bg='cyan', command=show)
    Button.pack(padx=5, pady=5)

    # frame (1, 1)
    my_frame = frame[1][1]

    def play():
        dataset_name = text1[RadioVar.get()]
        model_name = entry1.get()
        mut_name = detail_modes[RadioVar2.get()][RadioVar3.get()] if RadioVar2.get() > 0 else 'new_original'
        print(dataset_name, model_name, mut_name, sep='|')

        nonlocal window
        window.destroy()

        from main import play
        if dataset_name == 'MNIST':
            from MNIST import l_dim, define_discriminator, define_generator, define_gan, load_real_samples
        else:
            print('dataset not found')
            raise NameError
        play(l_dim, define_discriminator, define_generator, define_gan, load_real_samples(), load_real_samples(),
             model_name=None, mut_name=mut_name)

    Button = tk.Button(my_frame, text='play', width=10, height=2, bg='cyan', command=play)
    Button.pack(padx=5, pady=5)

    window.mainloop()


if __name__ == '__main__':
    create_window()
