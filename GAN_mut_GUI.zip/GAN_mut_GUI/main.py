# write mutations for your GAN at line 150

import os
from matplotlib import pyplot
from numpy import zeros, ones, vstack
from numpy.random import randn, randint
from tensorflow.python.keras.models import load_model

import model_mut_model_generators
import tools

flag_confuse_discriminator = False
flag_random_reduction = False


# select real samples
def generate_real_samples(dataset, n_samples):
    # choose random instances
    ix = randint(0, dataset.shape[0], n_samples)
    # retrieve selected images
    x = dataset[ix]
    # generate 'real' class labels (1)
    y = ones((n_samples, 1))
    if flag_confuse_discriminator and randint(0, tools.parameters['confuse_discriminator']) == 0:
        y[0][0] = 0
    return x, y


# generate points in latent space as input for the generator
def generate_latent_points(latent_dim, n_samples):
    # generate points in the latent space
    if flag_random_reduction:
        x_input = tools.random_reduction(latent_dim, n_samples)
    else:
        x_input = randn(latent_dim * n_samples)
    # reshape into a batch of inputs for the network
    x_input = x_input.reshape(n_samples, latent_dim)
    return x_input


# use the generator to generate n fake examples, with class labels
def generate_fake_samples(g_model, latent_dim, n_samples):
    x_input = generate_latent_points(latent_dim, n_samples)
    # predict outputs
    x = g_model.predict(x_input)
    # create 'fake' class labels (0)
    y = zeros((n_samples, 1))
    if flag_confuse_discriminator and randint(0, tools.parameters['confuse_discriminator']) == 0:
        y[0][0] = 1
    return x, y


# create and save a plot of generated images (reversed grayscale)
def save_plot(examples, epoch, n=10):
    # plot images
    for i in range(n * n):
        # define subplot
        pyplot.subplot(n, n, 1 + i)
        # turn off axis
        pyplot.axis('off')
        # plot raw pixel data
        pyplot.imshow(examples[i, :, :, 0], cmap='gray_r')
    # save plot to file
    filename = 'generated_plot_e%03d.png' % (epoch + 1)
    pyplot.savefig(filename)
    pyplot.close()


# evaluate the discriminator, plot generated images, save generator model
def summarize_performance(epoch, g_model, d_model, dataset, latent_dim, n_samples=100,
                          mut_name='original'):
    # prepare real samples
    x_real, y_real = generate_real_samples(dataset, n_samples)
    # evaluate discriminator on real examples
    _, acc_real = d_model.evaluate(x_real, y_real, verbose=0)
    # prepare fake examples
    x_fake, y_fake = generate_fake_samples(g_model, latent_dim, n_samples)
    # evaluate discriminator on fake examples
    _, acc_fake = d_model.evaluate(x_fake, y_fake, verbose=0)
    # summarize discriminator performance
    print('>Accuracy real: %.0f%%, fake: %.0f%%' % (acc_real * 100, acc_fake * 100))
    if mut_name:
        # save plot
        if n_samples == 100:
            save_plot(x_fake, epoch)
        # make direction
        if not os.path.exists(f'data/{mut_name}'):
            os.mkdir(f'data/{mut_name}')
        # save the generator model file
        filename = f'data\\{mut_name}\\generator_model_%03d.h5' % epoch
        g_model.save(filename)
        filename = f'data\\{mut_name}\\discriminator_model_%03d.h5' % epoch
        d_model.save(filename)
    return acc_real, acc_fake


# train the generator and discriminator
def train(g_model, d_model, gan_model, dataset, standard_dataset, latent_dim, n_epochs=100, n_batch=256,
          mut_name='original', calc_mut_score=True, test_period=10):
    bat_per_epo = int(dataset.shape[0] / n_batch)
    half_batch = int(n_batch / 2)
    # manually enumerate epochs
    for i in range(n_epochs):
        # enumerate batches over the training set
        for j in range(bat_per_epo):
            # get randomly selected 'real' samples
            x_real, y_real = generate_real_samples(dataset, half_batch)
            # generate 'fake' examples
            x_fake, y_fake = generate_fake_samples(g_model, latent_dim, half_batch)
            # create training set for the discriminator
            x, y = vstack((x_real, x_fake)), vstack((y_real, y_fake))
            # update discriminator model weights
            d_loss, _ = d_model.train_on_batch(x, y)
            # prepare points in latent space as input for the generator
            x_gan = generate_latent_points(latent_dim, n_batch)
            # create inverted labels for the fake samples
            y_gan = ones((n_batch, 1))
            # update the generator via the discriminator's error
            g_loss = gan_model.train_on_batch(x_gan, y_gan)
            # summarize loss on this batch
            print('>%d, %d/%d, d=%.3f, g=%.3f' % (i + 1, j + 1, bat_per_epo, d_loss, g_loss))
        # evaluate the model performance, sometimes
        if (i + 1) % test_period == 0:
            summarize_performance(i + 1, g_model, d_model, dataset, latent_dim, mut_name=mut_name)

            if calc_mut_score:
                # calculate mutation score
                standard_d_model = load_model(f'data\\original\\discriminator_model_{i + 1}.h5')
                another_g_model = load_model(f'data\\another\\generator_model_{i + 1}.h5')
                p = summarize_performance(i + 1, another_g_model, standard_d_model, standard_dataset,
                                          latent_dim, n_samples=1000, mut_name='')[1]
                p_prime = summarize_performance(i + 1, g_model, standard_d_model, standard_dataset,
                                                latent_dim, n_samples=1000, mut_name='')[1]
                print(f'Mutation Score == {abs(p_prime - p) / p}')


# train and get mutation score
def test(latent_dim, d_model, g_model, gan_model, dataset, standard_dataset, n_epochs=100, n_batch=256,
         model_name=None, mut_name='new_original', test_period=10):
    max_index = n_epochs // test_period * test_period

    # check original discriminator
    if not os.path.exists(f'data\\original\\discriminator_model_{max_index}.h5'):
        # create the discriminator
        d_model_ = define_discriminator(model_name=model_name)
        # create the generator
        g_model_ = define_generator(latent_dim, model_name=model_name)
        # create the gan
        gan_model_ = define_gan(g_model, d_model, model_name=model_name)
        train(g_model_, d_model_, gan_model_, dataset, None, latent_dim, n_epochs, n_batch,
              calc_mut_score=False, test_period=test_period)

    # check original generator of an another original GAN
    if not os.path.exists(f'data\\another\\generator_model_{max_index}.h5'):
        # create the discriminator
        d_model_ = define_discriminator(model_name=model_name)
        # create the generator
        g_model_ = define_generator(latent_dim, model_name=model_name)
        # create the gan
        gan_model_ = define_gan(g_model, d_model, model_name=model_name)
        train(g_model_, d_model_, gan_model_, dataset, None, latent_dim, n_epochs, n_batch,
              mut_name='another', calc_mut_score=False, test_period=test_period)

    if os.path.exists(f'data\\{mut_name}\\generator_model_{max_index}.h5'):
        print(f'data\\{mut_name}\\generator_model_{max_index}.h5 exists')
        return

    # train model
    if mut_name in ['after_train_GF', 'after_train_NS', 'after_train_WS']:
        mut_operator = mut_name[-2:]
        for i in range(test_period, n_epochs, test_period):
            standard_d_model = load_model(f'data\\original\\discriminator_model_{i + 1}.h5')
            another_g_model = load_model(f'data\\another\\generator_model_{i + 1}.h5')
            g_model = model_mut_model_generators.ModelMutatedModelGenerators(). \
                generate_model_by_model_mutation(another_g_model, mut_operator, tools.parameters['after_train'])
            p = summarize_performance(i + 1, another_g_model, standard_d_model, standard_dataset, latent_dim,
                                      n_samples=1000, mut_name='')[1]
            p_prime = summarize_performance(i + 1, g_model, standard_d_model, standard_dataset, latent_dim,
                                            n_samples=1000, mut_name='')[1]
            print(f'Mutation Score == {abs(p_prime - p) / p}')
        return

    elif mut_name in ['batch_decrease', 'batch_increase']:
        if mut_name == 'batch_decrease':
            n_batch //= tools.parameters['batch']
        else:  # 'batch_increase'
            n_batch *= tools.parameters['batch']

    elif mut_name in ['change_normalization']:
        dataset = tools.change_norm(dataset, tools.parameters['change_normalization'])

    elif mut_name in ['noise_exponential', 'noise_gamma', 'noise_gauss']:
        dataset = tools.add_noise(dataset, mut_name, tools.parameters['add_noise'])

    elif mut_name == 'change_discriminator':
        d_model = tools.change_discriminator()

    elif mut_name == 'change_generator':
        g_model = tools.change_generator()

    elif mut_name == 'change_both_optimizer':
        d_model.compile(loss='binary_crossentropy', optimizer=tools.new_d_opt, metrics=['accuracy'])
        gan_model.compile(loss='binary_crossentropy', optimizer=tools.new_g_opt)

    elif mut_name == 'change_discriminator_optimizer':
        d_model.compile(loss='binary_crossentropy', optimizer=tools.new_d_opt, metrics=['accuracy'])

    elif mut_name == 'change_generator_optimizer':
        gan_model.compile(loss='binary_crossentropy', optimizer=tools.new_g_opt)

    elif mut_name == 'confuse_discriminator':
        global flag_confuse_discriminator
        flag_confuse_discriminator = True

    elif mut_name == 'random_reduction':
        global flag_random_reduction
        flag_random_reduction = True

    train(g_model, d_model, gan_model, dataset, standard_dataset, latent_dim, n_epochs, n_batch,
          mut_name=mut_name, test_period=test_period)

    flag_confuse_discriminator = False
    flag_random_reduction = False


def play(latent_dim, define_d, define_g, define_gan_, dataset, standard_dataset, n_epochs=100, n_batch=256,
         model_name=None, mut_name='new_original'):
    # latent_dim: size of the latent space
    # dataset: image data

    # create the discriminator
    d_model = define_d(model_name=model_name)
    # create the generator
    g_model = define_g(latent_dim, model_name=model_name)
    # create the gan
    gan_model = define_gan_(g_model, d_model, model_name=model_name)
    # train and get mutation score
    test(latent_dim, d_model, g_model, gan_model, dataset, standard_dataset, n_epochs, n_batch, model_name, mut_name)


if __name__ == '__main__':
    from MNIST import l_dim, define_discriminator, define_generator, define_gan, load_real_samples
    play(l_dim, define_discriminator, define_generator, define_gan, load_real_samples(), load_real_samples())
