from random import gauss
from keras.layers import Dense, Flatten, Conv2D, LeakyReLU, Dropout, UpSampling2D, Reshape
from keras.models import Sequential
from keras.optimizers import Adam
import numpy as np
from numpy.random import rand, randn, exponential, standard_gamma

from MNIST import l_dim

reduced_list = []
index = -1
seed = 37

new_d_opt = Adam(learning_rate=0.0004, beta_1=0.5)
new_g_opt = Adam(learning_rate=0.0002, beta_1=0.5)

parameters = {
    'after_train': .05,
    'batch': 2,
    'change_normalization': .05,
    'add_noise': .05,
    'confuse_discriminator': 100
}


def add_noise(dataset, mut_name, mut_ratio):
    if mut_name == 'noise_exponential':
        def noise_exp(image):
            if rand() > mut_ratio:
                return image
            var = .0001
            noise = exponential(var, image.shape)
            output = image + noise
            return output
        dataset = np.array(list(map(noise_exp, dataset)))
    elif mut_name == 'noise_gamma':
        def noise_gamma(image):
            if rand() > mut_ratio:
                return image
            var = .0001
            noise = standard_gamma(var, image.shape)
            output = image + noise
            return output
        dataset = np.array(list(map(noise_gamma, dataset)))
    elif mut_name == 'noise_gauss':
        def noise_gauss(image):
            if rand() > mut_ratio:
                return image
            var = .0001
            noise = gauss(var, image.shape)
            output = image + noise
            return output
        dataset = np.array(list(map(noise_gauss, dataset)))
    return dataset


def change_norm(dataset, mut_ratio):
    return dataset * (1 + mut_ratio)


def change_discriminator():
    model = Sequential()
    model.add(Conv2D(64, (3, 3), strides=(2, 2), padding='same', input_shape=(28, 28, 1)))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Dropout(0.4))
    model.add(Conv2D(64, (3, 3), strides=(2, 2), padding='same'))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Dropout(0.4))
    model.add(Flatten())
    model.add(Dense(1, activation='sigmoid'))
    # compile model
    opt = Adam(learning_rate=0.0002, beta_1=0.5)
    model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
    return model


def change_generator():
    model = Sequential()
    # foundation for 7x7 image
    n_nodes = 128 * 7 * 7
    model.add(Dense(n_nodes, input_dim=l_dim))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Reshape((7, 7, 128)))
    # upsample to 14x14
    model.add(UpSampling2D(size=(2, 2)))
    model.add(LeakyReLU(alpha=0.2))
    # upsample to 28x28
    model.add(UpSampling2D(size=(2, 2)))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Conv2D(1, (7, 7), activation='sigmoid', padding='same'))
    return model


def random_reduction(latent_dim, n_samples):
    global reduced_list, index
    if not reduced_list:
        reduced_list = [randn(latent_dim * n_samples) for _ in range(100)]
    index += 1
    return reduced_list[index % len(reduced_list)]
